const pokemonRoute = require('../routes/pokemon.route')
const pokemonTypeRoute = require('../routes/pokemon-type.route')

module.exports = {
    pokemonRoute,
    pokemonTypeRoute
}
